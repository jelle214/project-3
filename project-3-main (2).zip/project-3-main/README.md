https://www.figma.com/design/mSPKtpNgkXMiptnROW2pCC/stijlgids?node-id=1-3&t=3uwIFsvGsNMeZmzl-1      <----- figma stijlgids jelle link

https://www.figma.com/design/XJ1tj2SGtdzSjvRb3y3Ew3/Untitled?node-id=0-1&node-type=canvas&t=PBprVDqRIDF0RMzw-0 <-------- wireframes figma jelle
